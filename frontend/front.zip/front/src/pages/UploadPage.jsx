// src/pages/UploadPage.jsx
import React from 'react';
import CSVUpload from '../components/CSVUpload';

export default function UploadPage() {
  return <CSVUpload />;
}
